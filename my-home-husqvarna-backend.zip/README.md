# My Home — Husqvarna-connected backend

This backend keeps the Husqvarna Application Secret off the iPhone/iPad app.

## Setup

1. Install Node.js 20+.
2. Run:
   npm install
3. Set the two environment variables:
   HUSQVARNA_APPLICATION_KEY
   HUSQVARNA_APPLICATION_SECRET
4. Start:
   npm start

The server exposes:
GET /api/mowers
GET /api/mowers/:id
POST /api/mowers/:id/actions

Supported actions in this MVP:
START_MOWING
PAUSE
PARK_UNTIL_NEXT_SCHEDULE
PARK_UNTIL_FURTHER_NOTICE
RESUME_SCHEDULE

The application key and secret must never be put into the browser/iPad code.

## Important

The server is intentionally not pre-populated with the user's secret. The user must configure it privately during deployment.

Next:
- connect the existing My Home UI to these endpoints
- add Hive
- add Imou
- add So Energy/smart-meter data
- add EV charger once model is known
- add authentication for the My Home app itself
- deploy behind HTTPS
