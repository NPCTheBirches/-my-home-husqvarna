import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.HUSQVARNA_APPLICATION_KEY;
const API_SECRET = process.env.HUSQVARNA_APPLICATION_SECRET;
const AUTH_URL = "https://api.authentication.husqvarnagroup.dev/v1/oauth2/token";
const API_BASE = "https://api.amc.husqvarna.dev/v1";

let cachedToken = null;
let tokenExpiry = 0;

async function getToken() {
  if (cachedToken && Date.now() < tokenExpiry - 60000) return cachedToken;
  if (!API_KEY || !API_SECRET) throw new Error("Husqvarna credentials are not configured on the server.");

  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: API_KEY,
    client_secret: API_SECRET
  });

  const r = await fetch(AUTH_URL, {
    method: "POST",
    headers: {"Content-Type":"application/x-www-form-urlencoded"},
    body
  });
  if (!r.ok) throw new Error(`Husqvarna authentication failed: ${r.status}`);
  const data = await r.json();
  cachedToken = data.access_token;
  tokenExpiry = Date.now() + (Number(data.expires_in || 3600) * 1000);
  return cachedToken;
}

async function husqvarna(path, options={}) {
  const token = await getToken();
  const headers = {
    "Authorization-Provider": "husqvarna",
    "Authorization": `Bearer ${token}`,
    "X-Api-Key": API_KEY,
    ...(options.headers || {})
  };
  const r = await fetch(API_BASE + path, {...options, headers});
  const text = await r.text();
  if (!r.ok) throw new Error(`Husqvarna API ${r.status}: ${text}`);
  return text ? JSON.parse(text) : {};
}

app.get("/api/mowers", async (req,res)=>{
  try { res.json(await husqvarna("/mowers")); }
  catch(e){ res.status(502).json({error:e.message}); }
});

app.get("/api/mowers/:id", async (req,res)=>{
  try { res.json(await husqvarna(`/mowers/${encodeURIComponent(req.params.id)}`)); }
  catch(e){ res.status(502).json({error:e.message}); }
});

app.post("/api/mowers/:id/actions", async (req,res)=>{
  try {
    const allowed = ["START_MOWING","PAUSE","PARK_UNTIL_NEXT_SCHEDULE","PARK_UNTIL_FURTHER_NOTICE","RESUME_SCHEDULE"];
    if (!allowed.includes(req.body.action)) return res.status(400).json({error:"Unsupported action"});
    res.json(await husqvarna(`/mowers/${encodeURIComponent(req.params.id)}/actions`, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({data:{type:"mower-action",attributes:{action:req.body.action}}})
    }));
  } catch(e){ res.status(502).json({error:e.message}); }
});

app.listen(PORT,()=>console.log(`My Home server listening on ${PORT}`));
